<?php
$host = "localhost:3306";
$user = "web3";
$pass = "Ptitctf@123";
$dbname = "music_blog_2";
$con = mysqli_connect($host, $user, $pass, $dbname);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
