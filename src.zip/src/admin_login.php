
<!DOCTYPE html>
<html lang="en">

<head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.min.js"></script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="16x16" href="/public/assets/demo/logo.png">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Admin Login</title>
    <!-- CSS -->
    <link href="/public/assets/vendors/material-icons/material-icons.css" rel="stylesheet" type="text/css">
    <link href="/public/assets/vendors/mono-social-icons/monosocialiconsfont.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.4/sweetalert2.css" rel="stylesheet"
          type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet"
          type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.1.3/mediaelementplayer.min.css" rel="stylesheet"
          type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/0.7.0/css/perfect-scrollbar.min.css"
          rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
          type="text/css">
    <link href="/public/assets/css/style.css" rel="stylesheet" type="text/css">
    <!-- Head Libs -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
</head>
<body class="body-bg-full profile-page" style="background-image: url(/public/assets/demo/night.jpg)">
<?php
if (!isset($_COOKIE["auth_str"]) && empty($_COOKIE["auth_str"]) === true) {
    header("Location: index.php");
    exit();
}
require_once 'vendor/autoload.php';

use Firebase\JWT\JWT;

$secret_key = "Th1s_1s_pt1t_cTf_2020_s3cr3t_k3y";
$cookie = $_COOKIE["auth_str"];
$jwt_decode = (array)JWT::decode($cookie, $secret_key, array("HS256"));
if ($jwt_decode["role"] !== "admin") {
    header("Location: index.php");
    exit();
}
include 'connect_db.php';
function filter_data($string)
{
    $string = preg_replace("/ /i", "", $string);
    $string = preg_replace("/or/i", "", $string);
    $string = preg_replace("/and/i", "", $string);
    $string = preg_replace("/union/i", "", $string);
    $string = preg_replace("/select/i", "", $string);
    $string = preg_replace("/data/i", "", $string);
    $string = preg_replace("/base/i", "", $string);
    $string = preg_replace("/database/i", "", $string);
    $string = preg_replace("/user/i", "", $string);
    $string = preg_replace("/admin/i", "", $string);
    $string = preg_replace("/password/i", "", $string);
    $string = preg_replace("/all/i", "", $string);
    $string = preg_replace("/group_concat/i", "", $string);
    $string = preg_replace("/table_name/i", "", $string);
    $string = preg_replace("/from/i", "", $string);
    $string = preg_replace("/information_schema/i", "", $string);
    $string = preg_replace("/where/i", "", $string);
    $string = preg_replace("/-/i", "", $string);
    return $string;
}

if (!empty($_POST['username']) && !empty($_POST['password'])) {
    $messege = "";
    $username = filter_data($_POST['username']);
    $password = filter_data($_POST['password']);
    $query = "SELECT COUNT(*) FROM User Where Username = ('$username') AND Password = ('$password')";
    $data = $con->query($query);
    $arr = $data->fetch_array();
    $count = $arr[0];
    if ($count > 0) {
        $messege = "Welcome Admin";
    } else {
        $messege = "Invalid username or password";
    }
}
?>
<div id="wrapper" class="row wrapper">
    <div class="col-10 ml-sm-auto col-sm-6 col-md-4 ml-md-auto login-center mx-auto">
        <div class="navbar-header text-center">
            <a href="admin_login.php">
                <img alt="" src="/public/assets/demo/logo.png">
            </a>
        </div>
        <?php echo $messege; ?>
        <!-- /.navbar-header -->
        <form action="" method="POST" class="form-material">
            <div class="form-group">
                <input type="text" placeholder="Your Username" class="form-control form-control-line" name="username"
                       id="input1">
                <label for="username">Username</label>
            </div>
            <div class="form-group">
                <input type="password" placeholder="Your Password" class="form-control form-control-line"
                       name="password" id="input1">
                <label>Password</label>
            </div>
            <div class="form-group">
                <button class="btn btn-block btn-lg btn-color-scheme ripple" type="submit" value="login" name="login">
                    Login
                </button>
            </div>
    </div>
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript"
            src="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/public/assets/js/material-design.js"></script>
</body>
</html>
